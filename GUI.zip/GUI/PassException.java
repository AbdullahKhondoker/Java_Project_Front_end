import java.lang.*;

public class PassException  extends Exception  //user defined exception
{
	public String getMessage(){return "sorry the String is too short";}
}