
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class Login extends JFrame implements MouseListener,ActionListener
{
	ImageIcon img;
	JLabel loginLb,passLb,success,imgLabel,name;
	JTextField loginTF;
    JPasswordField passWord;
    JButton loginBtn, exitBtn;
    JPanel panel;
	Color myColor;
	Font myFont;
public Login()
{
	super("NAAM SCHOOL MANAGEMENT");
	this.setSize(1580,1051);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	myColor = new Color(210, 230, 135);
		myFont = new Font("Cambria", Font.PLAIN, 28);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.YELLOW);
		
		name = new JLabel("Welcome to NAAM SCHOOL");
		name.setBounds(400,180,360,80);
		//name.setBackground(Color.GREEN);
		name.setForeground(Color.BLUE);
		name.setFont(myFont);
		panel.add(name);
		
		loginLb = new JLabel("User Name :");
		loginLb.setBounds(400, 280, 160, 30);
		loginLb.setFont(myFont);
		panel.add(loginLb);
		
		loginTF = new JTextField ();
		loginTF.setBounds(560, 280, 100, 30);
		//loginTF.setBackground(Color.WHITE);
		panel.add(loginTF);
		
		passLb = new JLabel("Password   :");
		passLb.setBounds(400, 330, 150, 30);
		passLb.setFont(myFont);
		panel.add(passLb);
		
		passWord = new JPasswordField();
		passWord.setBounds(560,330,100,30);
		passWord.setEchoChar('*');
		panel.add(passWord);
		
		
		loginBtn = new JButton("Login");
		loginBtn.setBounds(400, 400, 80, 30);
		loginBtn.setBackground(Color.GREEN);
		loginBtn.addMouseListener(this);
		loginBtn.addActionListener(this);
		panel.add(loginBtn);
		
		exitBtn = new JButton("Leave");
		exitBtn.setBounds(520, 400, 80, 30);
		exitBtn.setBackground(Color.RED);
		exitBtn.addMouseListener(this);
		exitBtn.addActionListener(this);
		panel.add(exitBtn);
		
		success = new JLabel("");
		success.setBounds(150,260,120,30);
		panel.add(success);
		
		
		img = new ImageIcon("school.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,1580,1051);
		panel.add(imgLabel);
		this.add(panel);
}
		public void mouseClicked(MouseEvent me){}
	    public void mousePressed(MouseEvent me){}
	    public void mouseReleased(MouseEvent me){}
	    public void mouseEntered(MouseEvent me)
		{
			
		if(me.getSource() == loginBtn)
		{
			loginBtn.setBackground(Color.BLUE);
			loginBtn.setForeground(Color.WHITE);
		}
		else if(me.getSource() == exitBtn)
		{
			exitBtn.setBackground(Color.BLUE);
			exitBtn.setForeground(Color.WHITE);
		}
		else
		{
			
		}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource() == loginBtn)
		{
			loginBtn.setBackground(Color.GREEN);
			loginBtn.setForeground(Color.BLACK);
		}
		else if(me.getSource() == exitBtn)
		{
			exitBtn.setBackground(Color.RED);
			exitBtn.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		if(loginBtn.getText().equals(command))
		{
			//JOptionPane.showMessageDialog(this, "Hello");
			String s1 = loginTF.getText();
			String s2 = passWord.getText();
			//String s3 ="", s4="";
			if((s1.equals("Abdullah") || s1.equals("Alin") 
				||s1.equals("Neha") || s1.equals("Mayad")) && s2.equals("abdullah123"))
			{
				//success.setText("successful Login");
				showMessageDialog(null, "valid Username and password.");
				//String s5 = combo.getSelectedItem().toString();
				Selection sf = new Selection(s1, this);
				sf.setVisible(true);
				this.setVisible(false);
			}
			else
			{
				showMessageDialog(null, "Invalid Username or password!!");
			}
		}
        else if(exitBtn.getText().equals(command))
		{
			System.exit(0);
		}
		/*else if(insert.getText().equals(command))
		{
			showMessageDialog(null, "Interstion Successful!");
		}*/
		else
		{
			
		}
	}		
	
	
}