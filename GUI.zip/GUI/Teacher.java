import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JOptionPane;

public class Teacher extends JFrame implements ActionListener, MouseListener
{
	ImageIcon img;
	JLabel hLabel,l1,l2,l3,l4,l5,l6,tLabel,imgLabel ;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6;
	//JPasswordField passWord;
	JButton b1,b2,b3,backBtn;
	JPanel panel;
	Color myColor;
	Font myFont;
	Selection sl;
	Account1 accounts [] = new Account1[3] ;
	Account1 acc;
	
	public Teacher(Selection sl)
	{
		super ("Teacher Operations");
		this.setSize(1200,675);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this. sl = sl;
		myColor = new Color(210,210,210);
		myFont = new Font("Cambria",Font.PLAIN,22);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(myColor);
		
		hLabel = new JLabel("MANAGEMENT SECTION");
		hLabel.setBounds(50,10,300,100);
		hLabel.setForeground(Color.BLUE);
		hLabel.setFont(myFont);
		panel.add(hLabel);
		
		/*tLabel = new JLabel("Teachers Operation :");
		tLabel.setBounds(200,30,200,50);
		tLabel.setBackground(Color.BLUE);
		tLabel.setForeground(Color.WHITE);
		panel.add(tLabel);*/
		
		l1 = new JLabel("Add new Teacher");
		l1.setBounds(50,100,150,50);
		l1.setBackground(Color.GREEN);
		l1.setForeground(Color.BLACK);
		panel.add(l1);
		
		l2 = new JLabel("Teacher Name: ");
		l2.setBounds(50,150,100,50);
		l2.setForeground(Color.BLACK);
		panel.add(l2);
		
		tx1 = new JTextField();
		tx1.setBounds(150,165,100,30);
		panel.add(tx1);
		
		l3 = new JLabel("Subject :");
		l3.setBounds(50,200,100,50);
		l3.setForeground(Color.BLACK);
		panel.add(l3);
		
		tx2 =  new JTextField();
		tx2.setBounds(150,215,100,30);
		panel.add(tx2);
		
		b1 = new JButton("ADD ");
		b1.setBounds(70,280,100,50);
		b1.setBackground(Color.GREEN);
		b1.setForeground(Color.WHITE);
		b1.addMouseListener(this);
		b1.addActionListener(this);
		panel.add(b1);
		
		l4 = new JLabel("Remove Teacher");
		l4.setBounds(300,100,150,50);
		l4.setBackground(Color.BLUE);
		l4.setForeground(Color.BLACK);
		panel.add(l4);
		
		l5 = new JLabel("Teacher Name :");
		l5.setBounds(300,150,100,50);
		l5.setForeground(Color.BLACK);
		panel.add(l5);
		
		tx3 = new JTextField();
		tx3.setBounds(400,160,100,30);
		panel.add(tx3);
		
		b2 = new JButton("REMOVE");
		b2.setBounds(300,280,150,50);
		b2.setBackground(Color.RED);
		b2.setForeground(Color.WHITE);
		b2.addMouseListener(this);
		b2.addActionListener(this);
		panel.add(b2);
		
		
		backBtn = new JButton("BACK");
		backBtn.setBounds(660,280,70,50);
		backBtn.setBackground(Color.RED);
		backBtn.addMouseListener(this);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		
		img = new ImageIcon("2.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,1200,675);
		panel.add(imgLabel);
		this.add(panel);
		
		
		
		
	}
	
	public void addTeacher(String a)
	{
		int flag = 0;
		acc = new Account1(a);
		for(int i = 0; i<accounts.length;i++)
		{
			if(accounts[i] == null)
			{
				accounts[i]=acc;
				flag = 1;
				break;
			}
		}
		if(flag == 1){JOptionPane.showMessageDialog(null,"Insertion Complete");}
		else{JOptionPane.showMessageDialog(null,"Insertion Failed!!!");}
	}
	public void removeTeacher(String a)
	{
		int flag = 0;
		try{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i].getAccountHolderName().equals(a))
			{
				accounts[i] = null;
				flag = 1;
				break;
			}
		}
		}
		catch(NullPointerException npe)
		{
			System.out.println("UNSUCCESSFUL OPERATION");
		}
		if(flag == 1){JOptionPane.showMessageDialog(null, "Removed Complete!");}
		else {JOptionPane.showMessageDialog(null, "Unsuccesful operation!!!");}
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){} 
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource() == b1)
		{
			b1.setBackground(Color.BLUE);
			b1.setForeground(Color.WHITE);
			
		}
		/*else if (me.getSource()== b2)
		{
			b1.setBackground(Color.BLACK);
			b1.setForeground(Color.WHITE);
		}
		else if (me.getSource() == backBtn)
		{
			backBtn.setBackground(Color.BLACK);
			backBtn.setForeground(Color.WHITE);
		}
	else {}*/
	
	}
	
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource() == b1)
		{
			b1.setBackground(Color.GREEN);
			b1.setForeground(Color.BLACK);
		}
		/*if(me.getSource() == b2)
		{
			b2.setBackground(Color.BLUE);
			b2.setForeground(Color.WHITE);
		}
		else if (me.getSource() == backBtn)
		{
			backBtn.setBackground(Color.RED);
			backBtn.setForeground(Color.BLACK);
		}
		else{}*/
	}
	
	//@override	
	public void actionPerformed(ActionEvent ae)
	{
		String s1 = tx1.getText();
		String s2 = tx3.getText();
		if(ae.getSource() == b1)
		{
			addTeacher(s1);
		}
		else if (ae.getSource() == b2)
		{
			removeTeacher(s2);
		}
		else if (ae.getSource() == backBtn)
		{
		sl.setVisible(true);
        this.setVisible(false);		
		}
		else{}
	}
	
	
	
	
	
	
	
}
